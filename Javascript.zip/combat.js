class Gladiateur {
  constructor(attaque, defense) {
    this.attaque = attaque;
    this.pts2vie = pts2vie;
    this.precision = precision;
    this.nom = nom; 
}
}{
    Attaquer(){
        console.log(this.attaque);
        adversaire.pointsDeVie -= this.attaque
        console.log();
        } else {
            console.log();
    }
}
{
    Precision(){
        if (Math.random() < this.Precision) {
            
        }
    }
}
let Ice spice = new Gladiateur(10,5);
let Maximus = new Gladiateur(10, 5);

while (Ice spice.pts2vie > 0 && Maximus.pts2vie > 0
    Ice spice.Attaquer(Maximus)
    Maximus.Attaquer(Ice spice)
)
